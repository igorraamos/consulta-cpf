import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { cpfSchema } from "@shared/schema";
import { ZodError } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Adicionar cabeçalhos CORS para compatibilidade com Vercel
  app.use((req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    
    if (req.method === 'OPTIONS') {
      return res.status(200).end();
    }
    
    next();
  });
  
  // Health check endpoint para a Vercel
  app.get("/api/health", (req, res) => {
    res.status(200).json({ status: "ok", timestamp: new Date().toISOString() });
  });
  
  // API route to consult CPF
  app.post("/api/cpf/consulta", async (req, res) => {
    try {
      // Validate the request body using cpfSchema
      const { cpf } = cpfSchema.parse(req.body);
      
      // Get CPF data from storage
      const cpfData = await storage.consultCpf(cpf);
      
      if (!cpfData) {
        return res.status(404).json({ 
          message: "CPF não encontrado na base de dados da Receita Federal." 
        });
      }
      
      // Return the data
      return res.status(200).json(cpfData);
    } catch (error) {
      // Handle validation errors
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "CPF inválido. Verifique o formato informado." 
        });
      }
      
      // Handle other errors
      console.error("Erro na consulta de CPF:", error);
      return res.status(500).json({ 
        message: "Erro ao processar a consulta. Tente novamente mais tarde." 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
