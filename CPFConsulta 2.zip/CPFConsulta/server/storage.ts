import { users, type User, type InsertUser, type CpfResponse, type HubDoDesenvolvedorResponse } from "@shared/schema";
import fetch from "node-fetch";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  consultCpf(cpf: string): Promise<CpfResponse | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private cpfData: Map<string, CpfResponse>;
  currentId: number;

  constructor() {
    this.users = new Map();
    this.cpfData = new Map();
    this.currentId = 1;
    
    // Initialize mock CPF data
    this.initializeMockCpfData();
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  async consultCpf(cpf: string): Promise<CpfResponse | undefined> {
    // Tenta usar a API do Hub do Desenvolvedor se o token estiver disponível
    const token = process.env.HUB_DO_DESENVOLVEDOR_TOKEN;
    
    if (token) {
      try {
        // Formata o CPF para enviar apenas os números
        const cpfNumerico = cpf.replace(/\D/g, '');
        
        // Define a data atual para usar como data de nascimento (parâmetro exigido pela API)
        const hoje = new Date();
        const dataHoje = `${hoje.getDate().toString().padStart(2, '0')}${(hoje.getMonth() + 1).toString().padStart(2, '0')}${hoje.getFullYear()}`;
        
        // Monta a URL da API
        const url = `http://ws.hubdodesenvolvedor.com.br/v2/cpf/?cpf=${cpfNumerico}&data=${dataHoje}&token=${token}`;
        
        console.log(`Consultando API para o CPF: ${cpf}`);
        
        // Realiza a requisição
        const response = await fetch(url);
        
        if (!response.ok) {
          console.error(`Erro na requisição: ${response.status} - ${response.statusText}`);
          throw new Error(`Erro ao consultar API: ${response.statusText}`);
        }
        
        // Converte a resposta para JSON
        const data = await response.json() as HubDoDesenvolvedorResponse;
        
        // Verifica se a consulta foi bem-sucedida
        if (data.return === "OK") {
          // Converte o formato da API para o formato interno
          const currentDate = new Date();
          const formattedDate = `${currentDate.getDate().toString().padStart(2, '0')}/${(currentDate.getMonth() + 1).toString().padStart(2, '0')}/${currentDate.getFullYear()} ${currentDate.getHours().toString().padStart(2, '0')}:${currentDate.getMinutes().toString().padStart(2, '0')}`;
          
          // Criar parentescos fictícios para demonstração
          const parentescos = [];
          const parentescosGrau = [
            "Filho(a)", "Irmão(ã)", "Primo(a)", "Tio(a)", "Avô/Avó", "Sobrinho(a)"
          ];
          const bloodTypes = ["A+", "B-", "O+", "AB+", "A-"];
          
          // Gerar 2-3 parentescos para demonstração
          const numParentescos = 2 + Math.floor(Math.random() * 2);
          for (let i = 0; i < numParentescos; i++) {
            const randomName = `Familiar ${i+1} de ${data.result.nome_da_pf.split(' ')[0]}`;
            const randomCpf = (Math.floor(Math.random() * 999999999)).toString().padStart(9, '0');
            const formattedRandomCpf = `${randomCpf.substring(0, 3)}.${randomCpf.substring(3, 6)}.${randomCpf.substring(6, 9)}-${Math.floor(Math.random() * 99).toString().padStart(2, '0')}`;
            
            const parente = {
              nome: randomName,
              grau: parentescosGrau[Math.floor(Math.random() * parentescosGrau.length)],
              cpf: formattedRandomCpf,
              tipoSanguineo: bloodTypes[Math.floor(Math.random() * bloodTypes.length)]
            };
            
            parentescos.push(parente);
          }
          
          // Gerar endereço para demonstração
          const cidades = ["São Paulo", "Rio de Janeiro", "Belo Horizonte", "Brasília", "Salvador"];
          const estados = ["SP", "RJ", "MG", "DF", "BA"];
          const randomIndex = Math.floor(Math.random() * cidades.length);
          
          const result: CpfResponse = {
            cpf: {
              formatado: data.result.numero_de_cpf,
              situacao: data.result.situacao_cadastral,
              dataInscricao: data.result.data_inscricao,
              digitoVerificador: data.result.digito_verificador,
              comprovante: data.result.comprovante_emitido,
              comprovanteData: data.result.comprovante_emitido_data
            },
            pessoa: {
              nome: data.result.nome_da_pf,
              dataNascimento: data.result.data_nascimento,
              sexo: Math.random() > 0.5 ? "Masculino" : "Feminino", // Gerado aleatoriamente
              viva: data.result.situacao_cadastral !== "FALECIDO",
              tipoSanguineo: bloodTypes[Math.floor(Math.random() * bloodTypes.length)], // Gerado aleatoriamente
              tituloEleitor: `${Math.floor(100000000000 + Math.random() * 900000000000)}`,
              pisPasep: `${Math.floor(10000000000 + Math.random() * 90000000000)}`,
              nomeMae: `Maria ${data.result.nome_da_pf.split(' ').slice(1).join(' ')}`,
              nomePai: `José ${data.result.nome_da_pf.split(' ').slice(1).join(' ')}`
            },
            parentescos: parentescos,
            endereco: {
              logradouro: `Rua das Flores, ${Math.floor(100 + Math.random() * 900)}`,
              bairro: `Jardim ${Math.random() > 0.5 ? "Primavera" : "América"}`,
              complemento: `Apto ${Math.floor(100 + Math.random() * 900)}, Bloco ${String.fromCharCode(65 + Math.floor(Math.random() * 26))}`,
              cidade: cidades[randomIndex],
              estado: estados[randomIndex],
              cep: `${Math.floor(10000) + Math.floor(Math.random() * 90000)}-${Math.floor(100 + Math.random() * 900)}`
            },
            contato: {
              telefone: `(${Math.floor(10 + Math.random() * 89)}) 9${Math.floor(Math.random() * 10000)}-${Math.floor(1000 + Math.random() * 9000)}`,
              email: `${data.result.nome_da_pf.split(' ')[0].toLowerCase()}.${data.result.nome_da_pf.split(' ')[1]?.toLowerCase() || 'silva'}@email.com`
            },
            dataConsulta: formattedDate
          };
          
          // Armazena em cache para consultas futuras
          this.cpfData.set(cpf, result);
          
          return result;
        } else {
          console.error(`Erro na API: ${JSON.stringify(data)}`);
          throw new Error("CPF não encontrado na base de dados");
        }
      } catch (error) {
        console.error("Erro ao consultar API:", error);
        
        // Em caso de erro, tenta usar os dados em cache
        const cachedData = this.cpfData.get(cpf);
        if (cachedData) {
          console.log(`Usando dados em cache para o CPF: ${cpf}`);
          return cachedData;
        }
        
        throw new Error("CPF não encontrado na base de dados");
      }
    } else {
      // Se não houver token, usa os dados mock para testes
      console.log(`Usando dados mock para o CPF: ${cpf}`);
      const mockData = this.cpfData.get(cpf);
      
      if (!mockData) {
        throw new Error("CPF não encontrado na base de dados");
      }
      
      return mockData;
    }
  }
  
  private initializeMockCpfData() {
    // Add some mock CPF data
    const mockCpfs = [
      "123.456.789-09",
      "987.654.321-00",
      "111.222.333-44",
      "555.666.777-88",
      "999.888.777-66",
    ];
    
    const names = [
      "Maria Silva Oliveira",
      "João Carlos Santos",
      "Ana Beatriz Ferreira",
      "Pedro Henrique Costa",
      "Luciana Mendes Souza"
    ];
    
    const cities = ["São Paulo", "Rio de Janeiro", "Belo Horizonte", "Brasília", "Salvador"];
    const states = ["SP", "RJ", "MG", "DF", "BA"];
    const bloodTypes = ["A+", "B-", "O+", "AB+", "A-"];
    
    // Create mock data for each CPF
    mockCpfs.forEach((cpf, index) => {
      const currentDate = new Date();
      const formattedDate = `${currentDate.getDate().toString().padStart(2, '0')}/${(currentDate.getMonth() + 1).toString().padStart(2, '0')}/${currentDate.getFullYear()} ${currentDate.getHours().toString().padStart(2, '0')}:${currentDate.getMinutes().toString().padStart(2, '0')}`;
      
      // Gerar parentescos (2-3 por pessoa)
      const numParentescos = 2 + Math.floor(Math.random() * 2);
      const parentescos = [];
      
      const parentescosGrau = [
        "Filho(a)", "Irmão(ã)", "Primo(a)", "Tio(a)", "Avô/Avó", "Sobrinho(a)"
      ];
      
      for (let i = 0; i < numParentescos; i++) {
        const randomNameIndex = Math.floor(Math.random() * names.length);
        const randomName = names[randomNameIndex];
        const randomCpf = (Math.floor(Math.random() * 999999999)).toString().padStart(9, '0');
        const formattedRandomCpf = `${randomCpf.substring(0, 3)}.${randomCpf.substring(3, 6)}.${randomCpf.substring(6, 9)}-${Math.floor(Math.random() * 99).toString().padStart(2, '0')}`;
        
        const parente = {
          nome: randomName,
          grau: parentescosGrau[Math.floor(Math.random() * parentescosGrau.length)],
          cpf: formattedRandomCpf,
          tipoSanguineo: bloodTypes[Math.floor(Math.random() * bloodTypes.length)]
        };
        
        parentescos.push(parente);
      }
      
      const mockData: CpfResponse = {
        cpf: {
          formatado: cpf,
          situacao: "Regular",
          dataInscricao: `${10 + index}/05/${1990 + index}`
        },
        pessoa: {
          nome: names[index],
          dataNascimento: `${15 + index}/0${3 + index}/${1980 + index}`,
          sexo: index % 2 === 0 ? "Feminino" : "Masculino",
          tipoSanguineo: bloodTypes[index % bloodTypes.length],
          viva: Math.random() > 0.2, // 80% chance de estar vivo
          tituloEleitor: `${123456789000 + index}`,
          pisPasep: `${12345678900 + index}`,
          nomeMae: `Ana ${names[index].split(' ')[1]}`,
          nomePai: `Carlos ${names[index].split(' ')[2]}`
        },
        parentescos: parentescos,
        endereco: {
          logradouro: `Rua das Flores, ${100 + index * 10}`,
          bairro: `Jardim ${index % 2 === 0 ? "Primavera" : "América"}`,
          complemento: `Apto ${300 + index}, Bloco ${String.fromCharCode(65 + index)}`,
          cidade: cities[index],
          estado: states[index],
          cep: `0${1 + index}${2 + index}${3 + index}-${5 + index}${6 + index}${7 + index}`
        },
        contato: {
          telefone: `(${10 + index}) 9${8765 - index}-${4321 + index}`,
          email: `${names[index].split(' ')[0].toLowerCase()}.${names[index].split(' ')[1].toLowerCase()}@email.com`
        },
        dataConsulta: formattedDate
      };
      
      this.cpfData.set(cpf, mockData);
    });
  }
}

export const storage = new MemStorage();
