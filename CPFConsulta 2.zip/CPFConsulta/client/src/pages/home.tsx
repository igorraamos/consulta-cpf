import { useState } from "react";
import CpfInputForm from "@/components/cpf-input-form";
import LoadingState from "@/components/loading-state";
import ErrorState from "@/components/error-state";
import CpfResult from "@/components/cpf-result";
import { CpfResponse } from "@shared/schema";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

type ViewState = "form" | "loading" | "result" | "error";

export default function Home() {
  const [viewState, setViewState] = useState<ViewState>("form");
  const [cpfData, setCpfData] = useState<CpfResponse | null>(null);
  const [errorMessage, setErrorMessage] = useState<string>("");
  const { toast } = useToast();

  const consultCpfMutation = useMutation({
    mutationFn: async (cpf: string) => {
      const response = await apiRequest("POST", "/api/cpf/consulta", { cpf });
      const data = await response.json();
      return data as CpfResponse;
    },
    onSuccess: (data) => {
      setCpfData(data);
      setViewState("result");
      toast({
        title: "Consulta realizada com sucesso",
        description: `Dados do CPF ${data.cpf.formatado} obtidos com sucesso.`,
        variant: "default",
      });
    },
    onError: (error: Error) => {
      setErrorMessage(error.message || "Erro ao consultar CPF. Tente novamente mais tarde.");
      setViewState("error");
      toast({
        title: "Erro na consulta",
        description: "Não foi possível obter os dados do CPF. Tente novamente.",
        variant: "destructive",
      });
    }
  });

  const handleConsultCpf = (cpf: string) => {
    setViewState("loading");
    consultCpfMutation.mutate(cpf);
  };

  const handleTryAgain = () => {
    setViewState("form");
    setErrorMessage("");
  };

  const handleNewConsultation = () => {
    setViewState("form");
    setCpfData(null);
  };

  return (
    <div className="min-h-screen">
      {/* Header com gradiente */}
      <header className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-lg">
        <div className="container mx-auto px-4 py-5 flex flex-col md:flex-row md:items-center md:justify-between">
          <div className="flex items-center mb-4 md:mb-0">
            <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center mr-3">
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.8} stroke="currentColor" className="w-6 h-6">
                <path strokeLinecap="round" strokeLinejoin="round" d="M15 9h3.75M15 12h3.75M15 15h3.75M4.5 19.5h15a2.25 2.25 0 0 0 2.25-2.25V6.75A2.25 2.25 0 0 0 19.5 4.5h-15a2.25 2.25 0 0 0-2.25 2.25v10.5A2.25 2.25 0 0 0 4.5 19.5Zm6-10.125a1.875 1.875 0 1 1-3.75 0 1.875 1.875 0 0 1 3.75 0Zm1.294 6.336a6.721 6.721 0 0 1-3.17.789 6.721 6.721 0 0 1-3.168-.789 3.376 3.376 0 0 1 6.338 0Z" />
              </svg>
            </div>
            <div>
              <h1 className="text-2xl font-bold">Consulta CPF</h1>
              <p className="text-sm text-blue-100">Sistema de verificação de dados na Receita Federal</p>
            </div>
          </div>
          <div className="flex space-x-4 items-center">
            <div className="hidden md:flex items-center text-sm bg-white/10 px-4 py-2 rounded-full">
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4 mr-2">
                <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 10.5V6.75a4.5 4.5 0 1 0-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 0 0 2.25-2.25v-6.75a2.25 2.25 0 0 0-2.25-2.25H6.75a2.25 2.25 0 0 0-2.25 2.25v6.75a2.25 2.25 0 0 0 2.25 2.25Z" />
              </svg>
              Ambiente Seguro
            </div>
            <div className="text-xs md:text-sm bg-blue-500 px-3 py-1 rounded-md">
              {new Date().toLocaleDateString('pt-BR')}
            </div>
          </div>
        </div>
      </header>
      
      {/* Hero Section - apenas visível na página inicial */}
      {viewState === "form" && (
        <div className="bg-white border-b">
          <div className="container mx-auto px-4 py-12 max-w-5xl">
            <div className="flex flex-col md:flex-row items-center justify-between">
              <div className="md:w-1/2 mb-8 md:mb-0 md:pr-12">
                <h2 className="text-3xl font-bold mb-4">
                  Consulta Completa de CPF
                </h2>
                <p className="text-gray-600 mb-6 text-lg">
                  Acesse informações detalhadas sobre qualquer CPF registrado na base da Receita Federal, incluindo dados pessoais, documentos, endereço e parentescos.
                </p>
                <div className="bg-blue-50 border border-blue-100 rounded-lg p-4 mb-4">
                  <div className="flex items-start">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="#2563eb" className="w-6 h-6 mr-3 mt-0.5 flex-shrink-0">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M11.25 11.25l.041-.02a.75.75 0 011.063.852l-.708 2.836a.75.75 0 001.063.853l.041-.021M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9-3.75h.008v.008H12V8.25z" />
                    </svg>
                    <div>
                      <h4 className="font-semibold text-blue-800 mb-1">Dados disponíveis na consulta</h4>
                      <ul className="text-sm text-blue-600 space-y-1">
                        <li className="flex items-center">
                          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4 mr-1">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                          Situação cadastral e regularidade
                        </li>
                        <li className="flex items-center">
                          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4 mr-1">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                          Informações pessoais completas
                        </li>
                        <li className="flex items-center">
                          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4 mr-1">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                          Parentescos e filiação
                        </li>
                        <li className="flex items-center">
                          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4 mr-1">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                          Endereço residencial e contatos
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
              <div className="md:w-1/2 flex justify-center">
                <div className="bg-gradient-to-br from-blue-50 to-indigo-50 p-6 rounded-lg shadow-lg">
                  <CpfInputForm onSubmit={handleConsultCpf} />
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      <main className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Dynamic Content based on viewState */}
        {viewState === "loading" && <LoadingState />}
        {viewState === "error" && <ErrorState message={errorMessage} onTryAgain={handleTryAgain} />}
        {viewState === "result" && cpfData && <CpfResult data={cpfData} onNewConsultation={handleNewConsultation} />}
      </main>

      {/* Footer */}
      <footer className="bg-gray-800 text-white mt-auto">
        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-4">Consulta CPF</h3>
              <p className="text-gray-300 text-sm">
                Plataforma de consulta de informações cadastrais de CPF na base da Receita Federal.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Informações</h3>
              <ul className="space-y-2 text-sm text-gray-300">
                <li>Esta é uma aplicação demonstrativa</li>
                <li>Os dados são obtidos via API oficial</li>
                <li>Consulta segura e rápida</li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Legal</h3>
              <p className="text-gray-300 text-sm">
                Este sistema não é oficial e serve apenas como demonstração.
                Não armazenamos dados pessoais de consultas.
              </p>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-6 text-center text-gray-400 text-sm">
            <p>&copy; {new Date().getFullYear()} Consulta CPF. Todos os direitos reservados.</p>
            <div className="mt-4 flex items-center justify-center">
              <div className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white px-4 py-2 rounded-md font-bold flex items-center tv-signature">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5 mr-2">
                  <path d="M16.5 7.5h-9v9h9v-9Z" />
                  <path fillRule="evenodd" d="M8.25 2.25A.75.75 0 0 1 9 3v.75h2.25V3a.75.75 0 0 1 1.5 0v.75H15V3a.75.75 0 0 1 1.5 0v.75h.75a3 3 0 0 1 3 3v.75H21A.75.75 0 0 1 21 9h-.75v2.25H21a.75.75 0 0 1 0 1.5h-.75V15H21a.75.75 0 0 1 0 1.5h-.75v.75a3 3 0 0 1-3 3h-.75V21a.75.75 0 0 1-1.5 0v-.75h-2.25V21a.75.75 0 0 1-1.5 0v-.75H9V21a.75.75 0 0 1-1.5 0v-.75h-.75a3 3 0 0 1-3-3v-.75H3a.75.75 0 0 1 0-1.5h.75v-2.25H3a.75.75 0 0 1 0-1.5h.75V9H3a.75.75 0 0 1 0-1.5h.75v-.75a3 3 0 0 1 3-3h.75V3a.75.75 0 0 1 .75-.75ZM6 6.75A.75.75 0 0 1 6.75 6h10.5a.75.75 0 0 1 .75.75v10.5a.75.75 0 0 1-.75.75H6.75a.75.75 0 0 1-.75-.75V6.75Z" clipRule="evenodd" />
                </svg>
                Igor Dev
              </div>
              <span className="ml-2 font-mono text-gray-500">// Desenvolvido com ❤️</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
