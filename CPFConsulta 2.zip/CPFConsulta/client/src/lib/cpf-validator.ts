/**
 * Format CPF string to standard format (000.000.000-00)
 */
export function formatCpf(value: string): string {
  // Remove all non-digit characters
  let cpf = value.replace(/\D/g, '');
  
  // Only process if we have at least one digit
  if (cpf.length > 0) {
    // Format CPF as xxx.xxx.xxx-xx
    cpf = cpf.replace(/(\d{3})(\d)/, '$1.$2');
    cpf = cpf.replace(/(\d{3})(\d)/, '$1.$2');
    cpf = cpf.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
  }
  
  return cpf;
}

/**
 * Validate a CPF number
 * This implements the official Brazilian CPF validation algorithm
 */
export function validateCpf(cpf: string): boolean {
  // Remove non-digit characters
  cpf = cpf.replace(/\D/g, '');
  
  // Check length
  if (cpf.length !== 11) {
    return false;
  }
  
  // Check for known invalid CPFs (all same digits)
  if (/^(\d)\1+$/.test(cpf)) {
    return false;
  }
  
  // Validate first check digit
  let sum = 0;
  for (let i = 0; i < 9; i++) {
    sum += parseInt(cpf.charAt(i)) * (10 - i);
  }
  
  let remainder = (sum * 10) % 11;
  if (remainder === 10 || remainder === 11) {
    remainder = 0;
  }
  
  if (remainder !== parseInt(cpf.charAt(9))) {
    return false;
  }
  
  // Validate second check digit
  sum = 0;
  for (let i = 0; i < 10; i++) {
    sum += parseInt(cpf.charAt(i)) * (11 - i);
  }
  
  remainder = (sum * 10) % 11;
  if (remainder === 10 || remainder === 11) {
    remainder = 0;
  }
  
  if (remainder !== parseInt(cpf.charAt(10))) {
    return false;
  }
  
  return true;
}
