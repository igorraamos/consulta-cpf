import { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import SkeletonCpfResult from "./skeleton-cpf-result";

export default function LoadingState() {
  const [progress, setProgress] = useState(0);
  const [step, setStep] = useState(1);
  const steps = [
    "Conectando ao servidor",
    "Validando CPF",
    "Acessando banco de dados",
    "Consultando dados na Receita Federal",
    "Processando informações",
    "Preparando resultados"
  ];

  useEffect(() => {
    const progressInterval = setInterval(() => {
      setProgress(prev => {
        const increment = Math.random() * 12;
        const nextProgress = prev + increment;
        if (nextProgress >= 100) {
          clearInterval(progressInterval);
          return 100;
        }
        return nextProgress;
      });
    }, 300);

    const stepInterval = setInterval(() => {
      setStep(prev => {
        if (prev >= steps.length) {
          clearInterval(stepInterval);
          return prev;
        }
        return prev + 1;
      });
    }, 1200);

    return () => {
      clearInterval(progressInterval);
      clearInterval(stepInterval);
    };
  }, []);

  return (
    <div>
      {/* Informações de carregamento */}
      <Card className="bg-white rounded-lg shadow-lg border-t-4 border-blue-500 mb-8 animate-fade-in-up">
        <CardContent className="p-8 flex flex-col items-center">
          <div className="relative w-24 h-24 mb-6">
            <div className="absolute inset-0 rounded-full bg-blue-100 animate-ping opacity-25"></div>
            <div className="relative w-full h-full flex items-center justify-center bg-gradient-to-r from-blue-500 to-indigo-600 rounded-full shadow-lg">
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="white" className="w-12 h-12">
                <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z" />
              </svg>
            </div>
          </div>
          
          <h3 className="text-2xl font-bold text-gradient mb-2">Consultando CPF</h3>
          <p className="text-gray-600 text-center mb-6">
            {steps[step - 1] || "Finalizando consulta..."}
          </p>
          
          <div className="w-full max-w-md mb-6">
            <div className="h-1.5 bg-gray-200 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-blue-500 to-indigo-600 transition-all duration-300 shimmer-animation" 
                style={{ 
                  width: `${progress}%`,
                }}
              ></div>
            </div>
            <div className="flex justify-between mt-2 text-xs text-gray-500">
              <span>Progresso</span>
              <span>{Math.round(progress)}%</span>
            </div>
          </div>
          
          <div className="bg-blue-50 border border-blue-100 rounded-lg p-4 w-full max-w-md">
            <div className="flex items-start">
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="#2563eb" className="w-5 h-5 mr-3 mt-0.5 flex-shrink-0">
                <path strokeLinecap="round" strokeLinejoin="round" d="M11.25 11.25l.041-.02a.75.75 0 011.063.852l-.708 2.836a.75.75 0 001.063.853l.041-.021M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9-3.75h.008v.008H12V8.25z" />
              </svg>
              <div>
                <h4 className="font-semibold text-blue-800 text-sm mb-1">Consulta em andamento</h4>
                <p className="text-xs text-blue-600">
                  Estamos consultando os dados através da API oficial. 
                  Este processo pode levar alguns segundos.
                </p>
              </div>
            </div>
          </div>
          
          <div className="flex justify-center space-x-2 mt-8">
            <div className="w-2 h-2 rounded-full bg-blue-400 animate-bounce"></div>
            <div className="w-2 h-2 rounded-full bg-blue-500 animate-bounce" style={{ animationDelay: '0.2s' }}></div>
            <div className="w-2 h-2 rounded-full bg-blue-600 animate-bounce" style={{ animationDelay: '0.4s' }}></div>
          </div>
        </CardContent>
      </Card>
      
      {/* Skeleton loader que mostra como será o resultado */}
      <SkeletonCpfResult />
    </div>
  );
}
