import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { cpfSchema } from "@shared/schema";
import { formatCpf, validateCpf } from "@/lib/cpf-validator";

interface CpfInputFormProps {
  onSubmit: (cpf: string) => void;
}

export default function CpfInputForm({ onSubmit }: CpfInputFormProps) {
  const [cpf, setCpf] = useState<string>("");
  const [error, setError] = useState<string | null>(null);
  const [isValid, setIsValid] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatCpf(e.target.value);
    setCpf(formatted);
    
    if (formatted.length > 0) {
      const isValidCpf = validateCpf(formatted);
      setIsValid(isValidCpf);
      setError(isValidCpf ? null : "CPF inválido. Verifique o número informado.");
    } else {
      setIsValid(false);
      setError(null);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!isValid) {
      setError("CPF inválido. Verifique o número informado.");
      const form = document.querySelector('form');
      if (form) form.classList.add('error-shake');
      setTimeout(() => {
        const form = document.querySelector('form');
        if (form) form.classList.remove('error-shake');
      }, 500);
      return;
    }

    try {
      // Validate with zod
      cpfSchema.parse({ cpf });
      setIsLoading(true);
      onSubmit(cpf);
    } catch (err) {
      setError("CPF inválido. Verifique o formato.");
    }
  };

  // Sem redirecionamento para serviços externos

  return (
    <Card className="card-hover bg-white rounded-lg shadow-md animate-fade-in-up">
      <CardContent className="pt-6">
        <div className="mb-6 text-center">
          <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center mx-auto mb-4">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="#2563eb" className="w-8 h-8">
              <path strokeLinecap="round" strokeLinejoin="round" d="M15 9h3.75M15 12h3.75M15 15h3.75M4.5 19.5h15a2.25 2.25 0 0 0 2.25-2.25V6.75A2.25 2.25 0 0 0 19.5 4.5h-15a2.25 2.25 0 0 0-2.25 2.25v10.5A2.25 2.25 0 0 0 4.5 19.5Zm6-10.125a1.875 1.875 0 1 1-3.75 0 1.875 1.875 0 0 1 3.75 0Zm1.294 6.336a6.721 6.721 0 0 1-3.17.789 6.721 6.721 0 0 1-3.168-.789 3.376 3.376 0 0 1 6.338 0Z" />
            </svg>
          </div>
          <h3 className="text-lg font-semibold">Digite o CPF para consulta</h3>
          <p className="text-sm text-gray-500 mt-1">Insira o número completo com ou sem formatação</p>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <Label htmlFor="cpf" className="block text-sm font-medium text-gray-700 mb-1">CPF</Label>
            <div className="relative group">
              <Input
                id="cpf"
                name="cpf"
                className={`w-full px-4 py-6 transition-all focus:ring-2 focus:ring-offset-1 ${
                  error ? 'border-red-500 focus:ring-red-200' : 
                  isValid && cpf.length > 0 ? 'border-green-500 focus:ring-green-200' : 
                  'focus:ring-blue-200'
                }`}
                placeholder="000.000.000-00"
                maxLength={14}
                value={cpf}
                onChange={handleInputChange}
              />
              <div className="absolute inset-y-0 right-0 flex items-center pr-3">
                {cpf.length > 0 ? (
                  isValid ? (
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="#22c55e" className="w-6 h-6">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
                    </svg>
                  ) : (
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="#ef4444" className="w-6 h-6">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m9-.75a9 9 0 1 1-18 0 9 9 0 0 1 18 0Zm-9 3.75h.008v.008H12v-.008Z" />
                    </svg>
                  )
                ) : (
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="#9ca3af" className="w-6 h-6">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0ZM4.501 20.118a7.5 7.5 0 0 1 14.998 0A17.933 17.933 0 0 1 12 21.75c-2.676 0-5.216-.584-7.499-1.632Z" />
                  </svg>
                )}
              </div>
            </div>
            {error && (
              <div className="mt-2 flex items-center text-sm text-red-500 animate-fade-in-up">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4 mr-1 flex-shrink-0">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126ZM12 15.75h.007v.008H12v-.008Z" />
                </svg>
                <span>{error}</span>
              </div>
            )}
          </div>
          
          <Button 
            type="submit" 
            className={`w-full text-white font-medium py-6 transition-all ${
              isValid && !isLoading 
                ? 'btn-gradient' 
                : 'bg-gray-400 hover:bg-gray-500 cursor-not-allowed'
            }`}
            disabled={!isValid || isLoading}
          >
            {isLoading ? (
              <div className="flex items-center justify-center">
                <svg className="animate-spin -ml-1 mr-2 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                <span>Consultando...</span>
              </div>
            ) : (
              <div className="flex items-center justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 mr-2">
                  <path strokeLinecap="round" strokeLinejoin="round" d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z" />
                </svg>
                <span>Consultar CPF</span>
              </div>
            )}
          </Button>
        </form>

        {/* Sem redirecionamentos para consultas externas */}
      </CardContent>
    </Card>
  );
}
