import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

export default function SkeletonCpfResult() {
  // Função auxiliar para criar um skeleton com animação de shimmer
  const ShimmerSkeleton = ({ className = "" }: { className?: string }) => (
    <Skeleton className={`skeleton-pulse ${className}`} />
  );
  
  return (
    <div className="animate-fade-in-up">
      {/* Header do resultado */}
      <div className="bg-white shadow-md rounded-lg p-6 mb-6">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-4">
          <div className="flex items-center">
            <ShimmerSkeleton className="w-12 h-12 rounded-full mr-4" />
            <div>
              <ShimmerSkeleton className="h-6 w-48 mb-2" />
              <ShimmerSkeleton className="h-4 w-32" />
            </div>
          </div>
          <ShimmerSkeleton className="h-4 w-36 mt-2 md:mt-0" />
        </div>
        
        <div className="bg-blue-50 border border-blue-100 rounded-md p-4 flex items-center">
          <ShimmerSkeleton className="w-6 h-6 mr-4 rounded-full" />
          <div className="w-full">
            <ShimmerSkeleton className="h-5 w-48 mb-2" />
            <ShimmerSkeleton className="h-4 w-full max-w-md" />
          </div>
        </div>
      </div>
      
      {/* Situação Cadastral */}
      <Card className="bg-white rounded-lg shadow-md mb-6 overflow-hidden">
        <div className="bg-gradient-to-r from-blue-600 to-indigo-600 px-6 py-4">
          <ShimmerSkeleton className="h-6 w-36 bg-white/20" />
        </div>
        <CardContent className="p-6">
          <div className="flex items-center mb-6">
            <ShimmerSkeleton className="w-16 h-16 rounded-full mr-5" />
            <div>
              <ShimmerSkeleton className="h-3 w-24 mb-1" />
              <ShimmerSkeleton className="h-8 w-36 mb-2" />
              <ShimmerSkeleton className="h-5 w-28 rounded-full" />
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-gray-100">
            <div className="bg-gray-50 p-4 rounded-lg">
              <ShimmerSkeleton className="h-3 w-28 mb-2" />
              <ShimmerSkeleton className="h-5 w-full" />
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <ShimmerSkeleton className="h-3 w-24 mb-2" />
              <ShimmerSkeleton className="h-5 w-full" />
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Dados Pessoais */}
      <Card className="bg-white rounded-lg shadow-md mb-6 overflow-hidden">
        <div className="bg-gradient-to-r from-blue-600 to-indigo-600 px-6 py-4">
          <ShimmerSkeleton className="h-6 w-36 bg-white/20" />
        </div>
        <CardContent className="p-6">
          <div className="mb-6 pb-6 border-b border-gray-100">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between">
              <div className="flex items-center mb-4 md:mb-0">
                <ShimmerSkeleton className="w-14 h-14 rounded-full mr-4" />
                <div>
                  <ShimmerSkeleton className="h-3 w-28 mb-2" />
                  <ShimmerSkeleton className="h-7 w-48" />
                </div>
              </div>
              <ShimmerSkeleton className="h-6 w-28 rounded-full" />
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-gray-50 p-4 rounded-lg">
                <ShimmerSkeleton className="h-3 w-28 mb-2" />
                <ShimmerSkeleton className="h-5 w-full" />
              </div>
            ))}
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[1, 2].map((i) => (
              <div key={i} className="bg-gray-50 p-4 rounded-lg">
                <ShimmerSkeleton className="h-3 w-28 mb-2" />
                <ShimmerSkeleton className="h-5 w-full" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
      
      {/* Filiação */}
      <Card className="bg-white rounded-lg shadow-md mb-6 overflow-hidden">
        <div className="bg-gradient-to-r from-blue-600 to-indigo-600 px-6 py-4">
          <ShimmerSkeleton className="h-6 w-24 bg-white/20" />
        </div>
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[1, 2].map((i) => (
              <div key={i} className="bg-gray-50 p-4 rounded-lg flex">
                <ShimmerSkeleton className="w-12 h-12 rounded-full mr-4 flex-shrink-0" />
                <div className="w-full">
                  <ShimmerSkeleton className="h-3 w-16 mb-2" />
                  <ShimmerSkeleton className="h-5 w-full" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
      
      {/* Endereço */}
      <Card className="bg-white rounded-lg shadow-md mb-6 overflow-hidden">
        <div className="bg-gradient-to-r from-blue-600 to-indigo-600 px-6 py-4">
          <ShimmerSkeleton className="h-6 w-24 bg-white/20" />
        </div>
        <CardContent className="p-6">
          <div className="grid grid-cols-1 gap-4 mb-6">
            <ShimmerSkeleton className="h-5 w-full" />
            <ShimmerSkeleton className="h-5 w-3/4" />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-gray-50 p-4 rounded-lg">
                <ShimmerSkeleton className="h-3 w-20 mb-2" />
                <ShimmerSkeleton className="h-5 w-full" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}