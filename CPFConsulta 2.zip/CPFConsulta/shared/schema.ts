import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// CPF Consultation Schema
export const cpfSchema = z.object({
  cpf: z.string()
    .regex(/^\d{3}\.\d{3}\.\d{3}-\d{2}$/, "CPF deve estar no formato 000.000.000-00")
});

export const hubDoDesenvolvedorResponseSchema = z.object({
  status: z.boolean(),
  return: z.string(),
  consumed: z.number(),
  result: z.object({
    numero_de_cpf: z.string(),
    nome_da_pf: z.string(),
    data_nascimento: z.string(),
    situacao_cadastral: z.string(),
    data_inscricao: z.string(),
    digito_verificador: z.string(),
    comprovante_emitido: z.string(),
    comprovante_emitido_data: z.string()
  })
});

// Mantendo nossa estrutura interna para compatibilidade com o frontend
export const cpfResponseSchema = z.object({
  cpf: z.object({
    formatado: z.string(),
    situacao: z.string(),
    dataInscricao: z.string(),
    digitoVerificador: z.string().optional(),
    comprovante: z.string().optional(),
    comprovanteData: z.string().optional()
  }),
  pessoa: z.object({
    nome: z.string(),
    dataNascimento: z.string(),
    sexo: z.string().optional(),
    tipoSanguineo: z.string().optional(),
    viva: z.boolean().optional().default(true),
    tituloEleitor: z.string().optional(),
    pisPasep: z.string().optional(),
    nomeMae: z.string().optional(),
    nomePai: z.string().optional()
  }),
  parentescos: z.array(
    z.object({
      nome: z.string(),
      grau: z.string(),
      cpf: z.string(),
      tipoSanguineo: z.string().optional()
    })
  ).optional().default([]),
  endereco: z.object({
    logradouro: z.string().optional(),
    bairro: z.string().optional(),
    complemento: z.string().optional(),
    cidade: z.string().optional(),
    estado: z.string().optional(),
    cep: z.string().optional()
  }).optional(),
  contato: z.object({
    telefone: z.string().optional(),
    email: z.string().email().optional()
  }).optional(),
  dataConsulta: z.string()
});

export type HubDoDesenvolvedorResponse = z.infer<typeof hubDoDesenvolvedorResponseSchema>;
export type CpfResponse = z.infer<typeof cpfResponseSchema>;
