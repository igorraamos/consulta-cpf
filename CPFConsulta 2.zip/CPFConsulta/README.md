# Consulta de CPF - Aplicação Web

Esta aplicação permite consultar informações de CPF utilizando a API Hub do Desenvolvedor, exibindo dados pessoais, informações biométricas, relações familiares, documentos e endereço.

## Tecnologias Utilizadas

- Frontend: React, TailwindCSS, Shadcn UI, Framer Motion
- Backend: Node.js, Express
- API: Hub do Desenvolvedor (consulta de CPF)
- Deploy: Vercel e Netlify (serverless)

## Opções de Deploy

### Deploy na Vercel

#### Pré-requisitos

1. Conta na [Vercel](https://vercel.com/)
2. Token da API Hub do Desenvolvedor

#### Passos para Implantação

1. Faça fork ou clone este repositório para sua conta GitHub
2. Acesse a plataforma Vercel e importe o projeto a partir do GitHub
3. Configure as seguintes variáveis de ambiente:
   - `NODE_ENV`: `production`
   - `HUB_DO_DESENVOLVEDOR_TOKEN`: Seu token de acesso à API Hub do Desenvolvedor
4. Clique em "Deploy" e aguarde a conclusão da implantação

### Deploy na Netlify

#### Pré-requisitos

1. Conta na [Netlify](https://netlify.com/)
2. Token da API Hub do Desenvolvedor

#### Passos para Implantação

1. Faça fork ou clone este repositório para sua conta GitHub
2. Acesse a plataforma Netlify e importe o projeto a partir do GitHub
3. Na seção de configuração do build:
   - Build command: `npm run build`
   - Publish directory: `dist`
4. Configure as seguintes variáveis de ambiente:
   - `HUB_DO_DESENVOLVEDOR_TOKEN`: Seu token de acesso à API Hub do Desenvolvedor
5. Clique em "Deploy site" e aguarde a conclusão da implantação

## Desenvolvimento Local

Para executar o projeto localmente:

1. Clone o repositório
2. Instale as dependências: `npm install`
3. Configure o arquivo `.env` com seu token da API
4. Execute o servidor de desenvolvimento: `npm run dev`

## Funcionalidades

- Validação de CPF (formato e dígitos verificadores)
- Consulta de dados completos do CPF
- Exibição de informações pessoais, parentescos e endereço
- Integração com API real da Receita Federal (via Hub do Desenvolvedor)

## Licença

MIT