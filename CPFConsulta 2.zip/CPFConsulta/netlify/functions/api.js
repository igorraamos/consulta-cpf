'use strict';

const express = require('express');
const serverless = require('serverless-http');
const cors = require('cors');
const fetch = require('node-fetch');

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Inicializa dados mockados
const mockCpfData = {
  "123.456.789-09": {
    cpf: {
      numero: "12345678909",
      formatado: "123.456.789-09",
      valido: true
    },
    nome: "João da Silva",
    data_nascimento: "1980-05-15",
    situacao_cadastral: {
      codigo: 0,
      descricao: "Regular"
    },
    data_inscricao: "1995-08-20",
    digito_verificador: "09",
    data_atualizacao: "2022-03-10",
    documentos: {
      titulo_eleitoral: "789456123",
      identidade: {
        numero: "MG12345678",
        orgao_emissor: "SSP",
        uf_emissor: "MG"
      }
    },
    genero: "Masculino",
    informacoes_biometricas: {
      tipo_sanguineo: "O+",
      altura: 175,
      peso: 75,
      cor_olhos: "Castanhos"
    },
    status: {
      pessoa_viva: true,
      falecimento: null
    },
    parentesco: {
      pai: "José da Silva",
      mae: "Maria da Silva",
      conjuge: "Ana da Silva",
      filhos: [
        "Pedro da Silva",
        "Carla da Silva"
      ]
    },
    endereco: {
      logradouro: "Rua das Flores",
      numero: "123",
      complemento: "Apto 101",
      bairro: "Centro",
      cep: "30123-456",
      cidade: "Belo Horizonte",
      uf: "MG"
    },
    contato: {
      telefone: "(31) 3333-4444",
      celular: "(31) 99999-8888",
      email: "joao.silva@email.com"
    }
  }
};

// Endpoint para consulta de CPF
app.post('/api/cpf/consulta', async (req, res) => {
  try {
    const cpf = req.body.cpf;
    
    if (!cpf) {
      return res.status(400).json({ error: 'CPF não fornecido' });
    }

    // Remove caracteres não numéricos
    const cpfNumerico = cpf.replace(/[^0-9]/g, '');
    
    // Tenta consultar pela API do Hub do Desenvolvedor
    const hubToken = process.env.HUB_DO_DESENVOLVEDOR_TOKEN;
    
    if (hubToken) {
      try {
        const apiUrl = "https://api.hub.sandbox.br/document/v1/cpf/" + cpfNumerico;
        
        const response = await fetch(apiUrl, {
          method: 'GET',
          headers: {
            'accept': 'application/json',
            'authorization': 'Bearer ' + hubToken
          }
        });
        
        if (response.ok) {
          const apiData = await response.json();
          
          // Formata resposta para o padrão da aplicação
          const formattedData = {
            cpf: {
              numero: apiData.numero_de_cpf,
              formatado: apiData.numero_de_cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4'),
              valido: true
            },
            nome: apiData.nome_da_pf,
            data_nascimento: apiData.data_nascimento,
            situacao_cadastral: {
              codigo: 0,
              descricao: apiData.situacao_cadastral && apiData.situacao_cadastral.descricao ? apiData.situacao_cadastral.descricao : "Regular"
            },
            data_inscricao: apiData.data_inscricao,
            digito_verificador: apiData.digito_verificador,
            data_atualizacao: apiData.data_atualizacao,
            genero: apiData.genero,
            informacoes_biometricas: {
              tipo_sanguineo: apiData.tipo_sanguineo || "Não informado",
              altura: apiData.altura || 0,
              peso: apiData.peso || 0,
              cor_olhos: apiData.cor_olhos || "Não informado"
            },
            status: {
              pessoa_viva: !apiData.obito,
              falecimento: apiData.obito ? {
                data: apiData.obito.data,
                motivo: apiData.obito.motivo
              } : null
            },
            parentesco: {
              pai: apiData.filiacao && apiData.filiacao.pai ? apiData.filiacao.pai : "Não informado",
              mae: apiData.filiacao && apiData.filiacao.mae ? apiData.filiacao.mae : "Não informado",
              conjuge: apiData.conjuge || "Não informado",
              filhos: apiData.filhos || []
            },
            endereco: {
              logradouro: apiData.endereco && apiData.endereco.logradouro ? apiData.endereco.logradouro : "Não informado",
              numero: apiData.endereco && apiData.endereco.numero ? apiData.endereco.numero : "S/N",
              complemento: apiData.endereco && apiData.endereco.complemento ? apiData.endereco.complemento : "",
              bairro: apiData.endereco && apiData.endereco.bairro ? apiData.endereco.bairro : "Não informado",
              cep: apiData.endereco && apiData.endereco.cep ? apiData.endereco.cep : "Não informado",
              cidade: apiData.endereco && apiData.endereco.municipio ? apiData.endereco.municipio : "Não informado",
              uf: apiData.endereco && apiData.endereco.uf ? apiData.endereco.uf : "Não informado"
            },
            contato: {
              telefone: apiData.telefone || "Não informado",
              celular: apiData.celular || "Não informado",
              email: apiData.email || "Não informado"
            }
          };
          
          return res.json(formattedData);
        }
      } catch (error) {
        console.error('Erro ao consultar API externa:', error);
        // Em caso de erro, continua para usar dados mockados
      }
    }
    
    // Usa dados mockados se não conseguir usar a API ou se o CPF for específico para teste
    const cpfFormatado = cpfNumerico.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
    
    // Verifica se existe nos dados mockados
    if (mockCpfData[cpfFormatado]) {
      return res.json(mockCpfData[cpfFormatado]);
    }
    
    // Se não encontrou nos dados mockados, gera um mockado genérico
    const mockData = {
      cpf: {
        numero: cpfNumerico,
        formatado: cpfFormatado,
        valido: true
      },
      nome: "Pessoa Exemplo",
      data_nascimento: "1985-10-20",
      situacao_cadastral: {
        codigo: 0,
        descricao: "Regular"
      },
      data_inscricao: "2000-01-15",
      digito_verificador: cpfNumerico.slice(-2),
      data_atualizacao: "2023-01-10",
      documentos: {
        titulo_eleitoral: "123456789012",
        identidade: {
          numero: "MG12345678",
          orgao_emissor: "SSP",
          uf_emissor: "MG"
        }
      },
      genero: "Não informado",
      informacoes_biometricas: {
        tipo_sanguineo: "O+",
        altura: 170,
        peso: 70,
        cor_olhos: "Castanhos"
      },
      status: {
        pessoa_viva: true,
        falecimento: null
      },
      parentesco: {
        pai: "Nome do Pai Exemplo",
        mae: "Nome da Mãe Exemplo",
        conjuge: "Cônjuge Exemplo",
        filhos: ["Filho Exemplo 1", "Filho Exemplo 2"]
      },
      endereco: {
        logradouro: "Rua Exemplo",
        numero: "123",
        complemento: "Apto 101",
        bairro: "Bairro Exemplo",
        cep: "12345-678",
        cidade: "Cidade Exemplo",
        uf: "MG"
      },
      contato: {
        telefone: "(31) 3333-4444",
        celular: "(31) 99999-8888",
        email: "exemplo@email.com"
      }
    };
    
    res.json(mockData);
  } catch (error) {
    console.error('Erro ao processar requisição:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Rota padrão para verificar se a API está funcionando
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', message: 'API funcionando corretamente' });
});

// Handler para Netlify Functions
module.exports.handler = serverless(app);